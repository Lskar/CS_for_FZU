<?php
	$db_host = 'localhost';
	$db_database='blog';
	$db_username='user';
	$db_password='password';
?>
